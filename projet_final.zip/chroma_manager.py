import chromadb
import json
import numpy as np
from typing import List, Dict
import uuid

class VectorDatabase:
    def __init__(self, persist_directory="./data/chroma_db"):
        """Initialise la base de données vectorielle - VERSION CORRIGÉE"""
        self.persist_directory = persist_directory
        
        # CORRECTION ICI : Utiliser PersistentClient au lieu de Client
        self.client = chromadb.PersistentClient(path=persist_directory)
        
        # Nom de la collection
        self.collection_name = "tunisian_archaeology"
        
        print(f"🗄️  Initialisation de ChromaDB dans {persist_directory}")
    
    def create_collection(self):
        """Crée ou récupère une collection"""
        try:
            # Essayer de récupérer la collection existante
            self.collection = self.client.get_collection(self.collection_name)
            print(f"📂 Collection '{self.collection_name}' récupérée")
        except:
            # Créer une nouvelle collection
            self.collection = self.client.create_collection(
                name=self.collection_name,
                metadata={"description": "Sites archéologiques tunisiens"}
            )
            print(f"🆕 Collection '{self.collection_name}' créée")
        
        return self.collection
    
    def add_documents(self, chunks: List[Dict], embeddings: np.ndarray = None):
        """Ajoute des documents à la collection"""
        if not hasattr(self, 'collection'):
            self.create_collection()
        
        # Préparer les données
        ids = []
        documents = []
        metadatas = []
        
        for chunk in chunks:
            # Générer un ID unique
            chunk_id = str(uuid.uuid4())
            ids.append(chunk_id)
            documents.append(chunk['text'])
            metadatas.append(chunk['metadata'])
        
        print(f"📤 Ajout de {len(chunks)} documents à ChromaDB...")
        
        # Ajouter avec ou sans embeddings
        if embeddings is not None:
            self.collection.add(
                ids=ids,
                embeddings=embeddings.tolist(),  # Convertir en liste
                metadatas=metadatas,
                documents=documents
            )
        else:
            self.collection.add(
                ids=ids,
                metadatas=metadatas,
                documents=documents
            )
        
        print("✅ Documents ajoutés avec succès")
    
    def search(self, query: str, n_results: int = 3, filters: Dict = None):
        """Recherche des documents similaires"""
        if not hasattr(self, 'collection'):
            self.create_collection()
        
        print(f"🔍 Recherche pour: '{query}'")
        
        results = self.collection.query(
            query_texts=[query],
            n_results=n_results,
            where=filters,
            include=["documents", "metadatas", "distances"]
        )
        
        # Formater les résultats
        formatted_results = []
        if results['documents']:
            for i in range(len(results['documents'][0])):
                formatted_results.append({
                    'text': results['documents'][0][i],
                    'metadata': results['metadatas'][0][i],
                    'distance': results['distances'][0][i],
                    'score': 1 - results['distances'][0][i]  # Convertir distance en score
                })
        
        return formatted_results
    
    def get_collection_info(self):
        """Affiche des informations sur la collection"""
        if hasattr(self, 'collection'):
            count = self.collection.count()
            print(f"📊 Collection '{self.collection_name}': {count} documents")
            return count
        return 0

def build_vector_database():
    """Pipeline complet de construction de la base vectorielle"""
    # 1. Charger les chunks
    with open("data/processed/chunks.json", 'r', encoding='utf-8') as f:
        chunks = json.load(f)
    
    print(f"📄 Chargement de {len(chunks)} chunks")
    
    # 2. Générer les embeddings
    from embedding import EmbeddingGenerator
    embedder = EmbeddingGenerator()
    texts = [chunk['text'] for chunk in chunks]
    embeddings = embedder.generate_embeddings(texts)
    
    # 3. Créer et remplir ChromaDB
    db = VectorDatabase()
    db.add_documents(chunks, embeddings)
    
    # 4. Vérifier
    count = db.get_collection_info()
    
    # 5. Tester avec une recherche
    test_query = "Quels sont les sites archéologiques en Tunisie ?"
    results = db.search(test_query, n_results=2)
    
    print("\n🧪 Test de recherche:")
    print(f"Query: {test_query}")
    for i, res in enumerate(results, 1):
        print(f"\nRésultat {i}:")
        print(f"Score: {res['score']:.3f}")
        print(f"Site: {res['metadata']['site_archaeologique']}")
        print(f"Texte: {res['text'][:150]}...")
    
    return db

if __name__ == "__main__":
    build_vector_database()