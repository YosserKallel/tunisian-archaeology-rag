# src/evaluation.py
import json
from datetime import datetime
from typing import List, Dict, Tuple
import pandas as pd

class RAGEvaluator:
    """Évalue le chatbot selon les critères du professeur"""
    
    def __init__(self, chatbot):
        self.chatbot = chatbot
        self.results = []
        
    def get_test_questions(self) -> List[Tuple[str, str, List[str]]]:
        """10 questions variées comme demandé par le professeur"""
        return [
            # (type, question, mots_clés_attendus)
            ("FAIT", "Quelle est la capacité du théâtre de Dougga ?", 
             ["3500", "spectateurs", "théâtre", "Dougga"]),
            
            ("FAIT", "En quelle année Carthage a-t-elle été classée UNESCO ?", 
             ["1979", "UNESCO", "classée", "Carthage"]),
            
            ("COMPARAISON", "Comparez l'architecture de Carthage et Kerkouane", 
             ["punique", "romaine", "ports", "villas", "souterraines"]),
            
            ("FAIT", "Quelles sont les dimensions de l'amphithéâtre d'El Jem ?", 
             ["148", "124", "36", "mètres", "amphithéâtre"]),
            
            ("SYNTHÈSE", "Listez les sites archéologiques tunisiens classés UNESCO", 
             ["Carthage", "Dougga", "El Jem", "Kerkouane", "UNESCO"]),
            
            ("FAIT", "Quelle période historique représente Bulla Regia ?", 
             ["Numide", "Romain", "villas", "souterraines"]),
            
            ("COMPARAISON", "Quelles différences entre Sbeitla et Thuburbo Majus ?", 
             ["temples", "capitulins", "thermes", "byzantin"]),
            
            ("SYNTHÈSE", "Quels sites possèdent des mosaïques remarquables ?", 
             ["mosaïques", "Bulla Regia", "Carthage", "Dougga"]),
            
            ("FAIT", "Quand a été fondée Utique ?", 
             ["punique", "fondation", "ancienne", "Utique"]),
            
            ("SYNTHÈSE", "Quels sont les principaux défis de conservation ?", 
             ["conservation", "érosion", "restauration", "patrimoine"])
        ]
    
    def calculate_hallucination_score(self, response: str, context_sources: List[Dict]) -> float:
        """Mesure si la réponse invente des informations (0=hallucinations, 1=factuel)"""
        # Simple vérification : la réponse doit mentionner les sources
        source_mentions = 0
        for i in range(1, len(context_sources) + 1):
            if f"(Document {i})" in response or f"[Document {i}]" in response:
                source_mentions += 1
        
        if len(context_sources) > 0:
            return source_mentions / len(context_sources)
        return 0.0
    
    def calculate_relevance_score(self, sources: List[Dict]) -> float:
        """Mesure la pertinence des sources (score > 0.7 comme demandé)"""
        if not sources:
            return 0.0
        
        relevant_sources = [s for s in sources if s['score'] > 0.7]
        return len(relevant_sources) / len(sources)
    
    def evaluate_question(self, question_type: str, question: str, expected_keywords: List[str]) -> Dict:
        """Évalue une question unique"""
        print(f"\n🔍 Évaluation: {question_type} - '{question}'")
        
        # 1. Obtenir la réponse du chatbot
        result = self.chatbot.generate_response(question)
        
        # 2. Calculer les métriques
        # a) Présence des mots-clés attendus
        response_lower = result['response'].lower()
        keyword_hits = sum(1 for kw in expected_keywords if kw.lower() in response_lower)
        keyword_score = keyword_hits / len(expected_keywords) if expected_keywords else 0
        
        # b) Score d'hallucination
        hallucination_score = self.calculate_hallucination_score(
            result['response'], result.get('sources', [])
        )
        
        # c) Pertinence des sources
        relevance_score = self.calculate_relevance_score(result.get('sources', []))
        
        # d) Format de réponse (doit avoir **Réponse** et **Sources**)
        format_score = 1.0 if "**Réponse** :" in result['response'] and "**Sources** :" in result['response'] else 0.5
        
        # 3. Score global
        global_score = (
            keyword_score * 0.3 +
            (1 - hallucination_score) * 0.3 +  # Inversé: moins d'hallucinations = meilleur
            relevance_score * 0.2 +
            format_score * 0.2
        )
        
        evaluation = {
            "timestamp": datetime.now().isoformat(),
            "question_type": question_type,
            "question": question,
            "response": result['response'][:500] + "..." if len(result['response']) > 500 else result['response'],
            "confidence": result['confidence'],
            "num_sources": result.get('num_sources', 0),
            "metrics": {
                "keyword_score": round(keyword_score, 3),
                "hallucination_score": round(hallucination_score, 3),  # Plus bas = mieux
                "relevance_score": round(relevance_score, 3),
                "format_score": round(format_score, 3),
                "global_score": round(global_score, 3)
            },
            "expected_keywords": expected_keywords,
            "found_keywords": [kw for kw in expected_keywords if kw.lower() in response_lower],
            "missing_keywords": [kw for kw in expected_keywords if kw.lower() not in response_lower]
        }
        
        print(f"   ✓ Confiance: {result['confidence']:.1%}")
        print(f"   ✓ Sources: {result.get('num_sources', 0)} (pertinence: {relevance_score:.1%})")
        print(f"   ✓ Score global: {global_score:.1%}")
        
        return evaluation
    
    def run_full_evaluation(self):
        """Exécute l'évaluation complète avec 10 questions"""
        print("=" * 70)
        print("ÉVALUATION DU CHATBOT RAG - 10 QUESTIONS")
        print("Critères du professeur: faits, comparaisons, synthèses")
        print("=" * 70)
        
        test_questions = self.get_test_questions()
        
        for q_type, question, expected_keywords in test_questions:
            evaluation = self.evaluate_question(q_type, question, expected_keywords)
            self.results.append(evaluation)
        
        # Générer le rapport
        self.generate_report()
        
        return self.results
    
    def generate_report(self):
        """Génère un rapport d'évaluation détaillé"""
        if not self.results:
            print("Aucun résultat à reporter.")
            return
        
        # 1. Résumé statistique
        print("\n" + "=" * 70)
        print("📊 RAPPORT D'ÉVALUATION - SYNTHÈSE")
        print("=" * 70)
        
        # Calcul des moyennes
        avg_confidence = sum(r['confidence'] for r in self.results) / len(self.results)
        avg_global = sum(r['metrics']['global_score'] for r in self.results) / len(self.results)
        avg_relevance = sum(r['metrics']['relevance_score'] for r in self.results) / len(self.results)
        
        # Sources avec score > 0.7
        all_sources_count = sum(r['num_sources'] for r in self.results)
        good_sources = sum(1 for r in self.results if r['metrics']['relevance_score'] >= 0.7)
        
        print(f"\n📈 MÉTRIQUES GLOBALES:")
        print(f"  • Confiance moyenne: {avg_confidence:.1%}")
        print(f"  • Score global moyen: {avg_global:.1%}")
        print(f"  • Pertinence sources moyenne: {avg_relevance:.1%}")
        print(f"  • Questions avec sources pertinentes (>0.7): {good_sources}/10")
        print(f"  • Total sources utilisées: {all_sources_count}")
        
        # 2. Par type de question
        print(f"\n🔎 ANALYSE PAR TYPE DE QUESTION:")
        for q_type in ["FAIT", "COMPARAISON", "SYNTHÈSE"]:
            type_results = [r for r in self.results if r['question_type'] == q_type]
            if type_results:
                avg_score = sum(r['metrics']['global_score'] for r in type_results) / len(type_results)
                print(f"  • {q_type}: {len(type_results)} questions, score moyen: {avg_score:.1%}")
        
        # 3. Sauvegarder en JSON pour le rapport
        report_data = {
            "date_evaluation": datetime.now().isoformat(),
            "total_questions": len(self.results),
            "summary": {
                "avg_confidence": avg_confidence,
                "avg_global_score": avg_global,
                "avg_relevance_score": avg_relevance,
                "questions_with_good_sources": good_sources
            },
            "detailed_results": self.results
        }
        
        with open("evaluation_report.json", "w", encoding="utf-8") as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        print(f"\n💾 Rapport sauvegardé: evaluation_report.json")
        
        # 4. Générer un tableau CSV pour analyse
        self.generate_csv_report()
    
    def generate_csv_report(self):
        """Génère un CSV avec les résultats"""
        import csv
        
        with open("evaluation_results.csv", "w", newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            # En-tête
            writer.writerow([
                "Type", "Question", "Confiance", "Sources", 
                "Score Mots-clés", "Score Hallucinations", 
                "Score Pertinence", "Score Format", "Score Global"
            ])
            
            # Données
            for result in self.results:
                writer.writerow([
                    result['question_type'],
                    result['question'][:50] + "...",
                    f"{result['confidence']:.1%}",
                    result['num_sources'],
                    f"{result['metrics']['keyword_score']:.1%}",
                    f"{result['metrics']['hallucination_score']:.1%}",
                    f"{result['metrics']['relevance_score']:.1%}",
                    f"{result['metrics']['format_score']:.1%}",
                    f"{result['metrics']['global_score']:.1%}"
                ])
        
        print(f"📊 CSV généré: evaluation_results.csv")

def main():
    """Fonction principale pour exécuter l'évaluation"""
    from rag_pipeline import ArchaeologyChatbot
    from chroma_manager import VectorDatabase
    
    print("Initialisation du chatbot pour évaluation...")
    
    # Initialiser
    db = VectorDatabase()
    db.create_collection()
    chatbot = ArchaeologyChatbot(db)
    
    # Exécuter l'évaluation
    evaluator = RAGEvaluator(chatbot)
    evaluator.run_full_evaluation()
    
    print("\n✅ ÉVALUATION TERMINÉE")
    print("Fichiers générés:")
    print("  • evaluation_report.json - Rapport complet")
    print("  • evaluation_results.csv - Tableau des résultats")

if __name__ == "__main__":
    main()