from langchain_community.llms import Ollama
from typing import List, Dict, Optional
import warnings
from langdetect import detect, DetectorFactory
DetectorFactory.seed = 0
warnings.filterwarnings('ignore')

class ArchaeologyChatbot:
    def __init__(self, chroma_db):
        """Initialise le chatbot avec la base de données"""
        self.db = chroma_db
        
        # Initialiser le LLM avec Ollama
        print("🔄 Chargement du modèle Llama 2...")
        self.llm = Ollama(
            model="llama2:latest",
            temperature=0.1,
            top_p=0.9,
            num_ctx=2048
        )
        print("✅ Modèle Llama 2 chargé")
    
    def retrieve_context(self, query: str, n_results: int = 3) -> List[Dict]:
        """Récupère le contexte pertinent"""
        results = self.db.search(query, n_results=n_results)
        
        # Filtrer par score minimum
        filtered = [r for r in results if r['score'] > 0.7]
        
        if not filtered:
            print("⚠️  Aucun résultat avec score > 0.7")
            return results[:1]  # Retourner le meilleur même si score bas
        
        return filtered
    
    def format_prompt(self, query: str, context_results: List[Dict]) -> str:
        """Formate le prompt avec le contexte - VERSION EXACTE PROFESSEUR"""
        
        # Construire le contexte avec numérotation
        context_parts = []
        for i, res in enumerate(context_results, 1):
            source = res['metadata'].get('source', 'Document')
            site = res['metadata']['site_archaeologique']
            title = res['metadata'].get('parent_title', f'Document sur {site}')
            context_parts.append(f"[Document {i}: {title}]\nSource: {source}\nSite: {site}\nContenu: {res['text']}")
        
        context_text = "\n\n" + "---\n".join(context_parts) + "\n\n"
        
        # PROMPT EXACT selon les instructions
        prompt = f"""Tu es un expert en archéologie tunisienne. Tu dois répondre à la question en utilisant UNIQUEMENT les informations des documents fournis.

DOCUMENTS DISPONIBLES:
{context_text}

QUESTION: {query}

INSTRUCTIONS STRICTES:
1. Utilise EXCLUSIVEMENT les informations des documents ci-dessus
2. Formate ta réponse EXACTEMENT comme suit (ne change pas ce format):

**Réponse** : [Donne une réponse claire, précise et structurée en paragraphes]

**Sources** :
- [Titre du document 1] (source: [source], site: [site archéologique])
- [Titre du document 2] (source: [source], site: [site archéologique])
- [Titre du document N] (source: [source], site: [site archéologique])

3. Dans le texte de la réponse, cite les sources entre parenthèses après chaque information : (Document 1)
4. Si une information n'est pas dans les documents, ne l'invente pas
5. Si aucun document ne contient la réponse, écris exactement : "Je ne dispose pas d'information fiable sur ce point."

MAINTENANT, GÉNÈRE TA RÉPONSE:
"""
        
        return prompt
    
    def detect_language(self, text):
        """Détecte la langue du texte"""
        try:
            lang = detect(text[:500])  # Analyser les premiers 500 caractères
            if lang == 'fr':
                return 'fr'
            elif lang == 'ar':
                return 'ar'
            else:
                return 'en'
        except:
            return 'en'  # Par défaut
    
    def generate_response(self, query: str) -> Dict:
        """Génère une réponse à partir d'une question"""
        print(f"\n💭 Question: {query}")
        
        # 1. Récupération du contexte
        print("🔍 Recherche du contexte...")
        context_results = self.retrieve_context(query)
        
        if not context_results:
            return {
                "response": "Je ne dispose pas d'informations suffisantes pour répondre à cette question.",
                "sources": [],
                "confidence": 0.0
            }
        
        # 2. Construction du prompt
        prompt = self.format_prompt(query, context_results)
        
        # 3. Génération de la réponse
        print("🤖 Génération de la réponse...")
        response = self.llm.invoke(prompt)
        
        # 4. Extraction des sources
        sources = []
        for res in context_results:
            sources.append({
                "title": res['metadata'].get('parent_title', 'Document'),
                "site": res['metadata']['site_archaeologique'],
                "score": res['score'],
                "excerpt": res['text'][:100] + "..."
            })
        
        # 5. Calcul de confiance amélioré
        base_confidence = sum([r['score'] for r in context_results]) / len(context_results)
        
        # Ajustement selon le nombre de sources
        if len(context_results) >= 4:
            confidence = min(0.95, base_confidence + 0.3)
        elif len(context_results) >= 2:
            confidence = min(0.90, base_confidence + 0.2)
        else:
            confidence = base_confidence
        
        # Arrondir à 2 décimales
        confidence = round(confidence, 2)
        
        return {
            "response": response.strip(),
            "sources": sources,
            "confidence": confidence,
            "num_sources": len(sources)
        }
    
    def chat_loop(self):
        """Boucle de conversation interactive"""
        print("\n" + "="*50)
        print("🤖 CHATBOT ARCHÉOLOGIE TUNISIENNE")
        print("="*50)
        print("Tapez 'quit' pour quitter")
        print("-"*50)
        
        while True:
            try:
                # Demander la question
                query = input("\n❓ Votre question: ").strip()
                
                if query.lower() in ['quit', 'exit', 'q']:
                    print("👋 Au revoir !")
                    break
                
                if not query:
                    continue
                
                # Générer la réponse
                result = self.generate_response(query)
                
                # Afficher la réponse
                print("\n" + "="*50)
                print("📜 RÉPONSE:")
                print("="*50)
                print(result['response'])
                
                print("\n📚 SOURCES (confiance: {:.1%}):".format(result['confidence']))
                for i, source in enumerate(result['sources'], 1):
                    print(f"{i}. {source['title']} - {source['site']} (score: {source['score']:.3f})")
                
                print("="*50)
                
            except KeyboardInterrupt:
                print("\n\n👋 Interruption - Au revoir !")
                break
            except Exception as e:
                print(f"❌ Erreur: {e}")
                continue

# Fonction de test
def test_chatbot():
    """Teste le chatbot avec des exemples"""
    # Importer la base de données
    from chroma_manager import VectorDatabase
    
    print("🧪 Test du chatbot RAG...")
    
    # Charger la base de données
    db = VectorDatabase()
    db.create_collection()
    
    # Créer le chatbot
    chatbot = ArchaeologyChatbot(db)
    
    # Questions de test
    test_questions = [
        "Qu'est-ce que Carthage ?",
        "Quelle est la capacité de l'amphithéâtre d'El Jem ?",
        "Quels sont les monuments principaux de Dougga ?"
    ]
    
    for question in test_questions:
        print(f"\n{'='*60}")
        print(f"QUESTION: {question}")
        print('='*60)
        
        result = chatbot.generate_response(question)
        
        print(f"\nRÉPONSE:")
        print(result['response'])
        print(f"\nConfiance: {result['confidence']:.1%}")
        print(f"Sources utilisées: {result['num_sources']}")
        
        for source in result['sources']:
            print(f"  - {source['title']} ({source['score']:.3f})")
    
    return chatbot

if __name__ == "__main__":
    # Mode test
    # test_chatbot()
    
    # Mode conversation interactif
    from chroma_manager import VectorDatabase
    db = VectorDatabase()
    db.create_collection()
    chatbot = ArchaeologyChatbot(db)
    chatbot.chat_loop()