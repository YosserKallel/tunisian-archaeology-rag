import json
import os

def create_sample_data():
    """Crée des données d'exemple pour démarrer rapidement"""
    
    sample_documents = [
        {
            "id": "carthage_wikipedia_001",
            "title": "Carthage - Site archéologique",
            "content": """Carthage est un site archéologique situé en Tunisie. Fondée par les Phéniciens au IXe siècle av. J.-C., elle devient la capitale de l'empire carthaginois. Le site comprend plusieurs éléments majeurs : Les ports puniques : Double port caractéristique avec un port circulaire militaire et un port commercial. Les thermes d'Antonin : Les plus grands thermes romains d'Afrique, construits sous l'empereur Antonin le Pieux. Le théâtre romain : Théâtre encore utilisé aujourd'hui pour le Festival de Carthage. La colline de Byrsa : Acropole de la ville punique, aujourd'hui site du musée national de Carthage. Le site est classé au patrimoine mondial de l'UNESCO depuis 1979.""",
            "metadata": {
                "site_archaeologique": "Carthage",
                "region": "Tunis",
                "periodes": "Punique, Romain, Byzantin",  # CHANGÉ : liste -> string
                "date_construction": "IXe siècle av. J.-C.",
                "unesco_inscription": 1979,
                "source": "Wikipedia",
                "langue": "fr",
                "credibilite": 0.9,
                "mots_cles": "ports puniques, thermes d'Antonin, Byrsa, UNESCO"  # CHANGÉ
            }
        },
        {
            "id": "dougga_unesco_002",
            "title": "Dougga - Site archéologique romain",
            "content": """Dougga est un site archéologique situé dans le nord-ouest de la Tunisie. Considérée comme la ville romaine la mieux conservée d'Afrique du Nord. Principaux monuments : Le Capitole : Temple dédié à la triade capitoline (Jupiter, Junon, Minerve), construit en 166-167 ap. J.-C. Le théâtre : Construit vers 168-169 ap. J.-C., pouvant accueillir 3500 spectateurs. Les thermes liciniens : Thermes publics du IIIe siècle. Le mausolée libyco-punique : Tombeau pré-romain du IIe siècle av. J.-C. Le site s'étend sur 70 hectares et est inscrit au patrimoine mondial depuis 1997.""",
            "metadata": {
                "site_archaeologique": "Dougga",
                "region": "Béja",
                "periodes": "Numide, Romain, Byzantin",  # CHANGÉ
                "date_construction": "IIe siècle av. J.-C.",
                "unesco_inscription": 1997,
                "superficie": "70 hectares",
                "source": "UNESCO",
                "langue": "fr",
                "credibilite": 0.95,
                "mots_cles": "Capitole, théâtre, mausolée, thermes"  # CHANGÉ
            }
        },
        {
            "id": "el_jem_unesco_003",
            "title": "Amphithéâtre d'El Jem",
            "content": """L'amphithéâtre d'El Jem est un amphithéâtre romain situé dans la ville d'El Jem en Tunisie. Construit au IIIe siècle (vers 238 ap. J.-C.), c'est le plus grand amphithéâtre romain d'Afrique. Caractéristiques : Dimensions : 148 mètres de long, 124 mètres de large, 36 mètres de haut. Capacité : Environ 35 000 spectateurs. Architecture : Trois niveaux d'arcades, arène elliptique. État de conservation : Exceptionnellement bien conservé. Classé au patrimoine mondial de l'UNESCO en 1979.""",
            "metadata": {
                "site_archaeologique": "El Jem",
                "region": "Mahdia",
                "periodes": "Romain",  # CHANGÉ
                "date_construction": "IIIe siècle ap. J.-C.",
                "unesco_inscription": 1979,
                "capacite": "35 000 spectateurs",
                "source": "UNESCO",
                "langue": "fr",
                "credibilite": 0.95,
                "mots_cles": "amphithéâtre, arène, architecture romaine"  # CHANGÉ
            }
        }
    ]
    
    # Créer le dossier data s'il n'existe pas
    os.makedirs("data/raw", exist_ok=True)
    os.makedirs("data/processed", exist_ok=True)
    
    # Sauvegarder chaque document
    for doc in sample_documents:
        filename = f"data/raw/{doc['id']}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(doc, f, ensure_ascii=False, indent=2)
    
    print(f"✅ {len(sample_documents)} documents d'exemple créés dans data/raw/")
    return sample_documents

if __name__ == "__main__":
    create_sample_data()