import streamlit as st
import sys
import os

# Ajouter le dossier src au chemin
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from chroma_manager import VectorDatabase
from rag_pipeline import ArchaeologyChatbot

# Configuration de la page
st.set_page_config(
    page_title="Chatbot Archéologie Tunisienne",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS personnalisé
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        color: #2E86AB;
        text-align: center;
        margin-bottom: 1rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #5D5D5D;
        text-align: center;
        margin-bottom: 2rem;
    }
    .response-box {
        background-color: #F8F9FA;
        color: #000000; /* <-- ADD THIS LINE: Makes text black */
        border-radius: 10px;
        padding: 1.5rem;
        margin: 1rem 0;
        border-left: 5px solid #2E86AB;
    }
    .source-box {
        background-color: #E9F7EF;
        color: #000000;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        border: 1px solid #C8E6C9;
    }
    .confidence-high {
        color: #006400; /* Dark Green */
        font-weight: bold;
    }
    .confidence-medium {
        color: #b35900; /* Dark Orange */
        font-weight: bold;
    }
    .confidence-low {
        color: #8b0000; /* Dark Red */
        font-weight: bold;
    }
    .stButton button {
        background-color: #2E86AB;
        color: white;
        font-weight: bold;
        border: none;
        padding: 0.5rem 2rem;
        border-radius: 5px;
    }
</style>
""", unsafe_allow_html=True)

# Initialisation de session
@st.cache_resource
def initialize_chatbot():
    """Initialise le chatbot une seule fois"""
    with st.spinner("Chargement du chatbot..."):
        # Initialiser la base de données
        db = VectorDatabase()
        db.create_collection()
        
        # Initialiser le chatbot
        chatbot = ArchaeologyChatbot(db)
        
        # Afficher le nombre de documents
        count = db.get_collection_info()
        st.sidebar.success(f"✅ Base de connaissances: {count} documents")
        
        return chatbot

def get_confidence_color(confidence):
    """Retourne la classe CSS en fonction du score de confiance"""
    if confidence > 0.8:
        return "confidence-high"
    elif confidence > 0.6:
        return "confidence-medium"
    else:
        return "confidence-low"

def main():
    # En-tête
    st.markdown('<h1 class="main-header">🏛️ Chatbot Archéologie Tunisienne</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">Posez vos questions sur les sites archéologiques de Tunisie</p>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.image("https://upload.wikimedia.org/wikipedia/commons/c/ce/Flag_of_Tunisia.svg", width=100)
        st.markdown("### 🌍 Sites couverts")
        sites = ["Tous", "Carthage", "Dougga", "El Jem", "Sbeitla", "Kerkouane", "Bulla Regia"]
        selected_site = st.selectbox("Filtrer par site", sites)
        
        st.divider()
        
        st.markdown("### ⚙️ Paramètres")
        n_results = st.slider("Nombre de sources", 1, 5, 3)
        
        st.divider()
        
        st.markdown("### 💡 Exemples")
        example_questions = [
            "Qu'est-ce que Carthage ?",
            "Quelle est la capacité du théâtre de Dougga ?",
            "Quels sites sont classés UNESCO ?",
            "Quelles sont les caractéristiques de l'amphithéâtre d'El Jem ?"
        ]
        
        for q in example_questions:
            if st.button(f"💭 {q[:30]}..."):
                st.session_state.question = q
    
    # Zone principale
    col1, col2 = st.columns([3, 1])
    
    with col1:
        # Zone de saisie
        question = st.text_input(
            "**Posez votre question:**",
            placeholder="Ex: Quels sont les monuments principaux de Carthage ?",
            key="question_input",
            label_visibility="collapsed"
        )
    
    with col2:
        search_button = st.button("🔍 Rechercher", use_container_width=True, type="primary")
    
    # Historique dans session state
    if 'history' not in st.session_state:
        st.session_state.history = []
    
    # Traitement de la question
    if search_button and question:
        with st.spinner("Recherche dans les archives archéologiques..."):
            # Initialiser le chatbot
            chatbot = initialize_chatbot()
            
            # Générer la réponse
            result = chatbot.generate_response(question)
            
            # Ajouter à l'historique
            st.session_state.history.append({
                "question": question,
                "response": result["response"],
                "sources": result["sources"],
                "confidence": result["confidence"]
            })
            
            # Afficher la réponse
            st.markdown("---")
            
            # En-tête de réponse avec confiance
            col_res1, col_res2 = st.columns([3, 1])
            with col_res1:
                st.markdown("### 📜 Réponse")
            with col_res2:
                confidence_class = get_confidence_color(result["confidence"])
                st.markdown(f'<p class="{confidence_class}">Confiance: {result["confidence"]:.1%}</p>', unsafe_allow_html=True)
            
            # Extraire les parties Réponse et Sources
            response_text = result['response']
            
            if "**Réponse** :" in response_text and "**Sources** :" in response_text:
                # Séparer Réponse et Sources
                parts = response_text.split("**Sources** :")
                reponse_part = parts[0].replace("**Réponse** :", "").strip()
                sources_part = "**Sources** :" + parts[1] if len(parts) > 1 else ""
                
                # Afficher Réponse
                st.markdown(f'<div class="response-box">{reponse_part}</div>', unsafe_allow_html=True)
                
                # Afficher Sources
                if sources_part:
                    st.markdown("### 📚 Sources")
                    st.markdown(f'<div class="source-box">{sources_part}</div>', unsafe_allow_html=True)
            else:
                # Format alternatif
                st.markdown(f'<div class="response-box">{response_text}</div>', unsafe_allow_html=True)
            
            # Afficher les sources détaillées
            if result["sources"]:
                st.markdown("### 📖 Sources détaillées")
                
                for i, source in enumerate(result["sources"], 1):
                    with st.expander(f"**Source {i}:** {source['title']} (score: {source['score']:.3f})"):
                        st.write(f"**Site:** {source['site']}")
                        st.write(f"**Extrait:** {source['excerpt']}")
                        
                        # Barre de progression pour le score
                        st.progress(source['score'])
    
    # Historique des conversations
    if st.session_state.history:
        st.markdown("---")
        st.markdown("### 📖 Historique des questions")
        
        for i, item in enumerate(reversed(st.session_state.history[-3:]), 1):
            with st.expander(f"Q{i}: {item['question'][:50]}..."):
                st.write("**Réponse:**")
                st.write(item['response'][:200] + "..." if len(item['response']) > 200 else item['response'])
                
                st.write(f"**Confiance:** {item['confidence']:.1%}")
                st.write(f"**Sources utilisées:** {len(item['sources'])}")
    
    # Section d'information
    with st.expander("ℹ️ À propos de ce chatbot"):
        st.markdown("""
        **Technologies utilisées:**
        - **RAG (Retrieval-Augmented Generation)** pour des réponses factuelles
        - **Llama 2 latest** via Ollama pour la génération
        - **ChromaDB** pour la base vectorielle
        - **Sentence Transformers** pour les embeddings
        
        **Sources des données:**
        - Documents académiques sur l'archéologie tunisienne
        - Fiches UNESCO des sites classés
        - Articles vérifiés sur le patrimoine
        
        **⚠️ Limitations:**
        - Ne couvre que les sites archéologiques principaux
        - Réponses basées uniquement sur les données fournies
        - Peut ne pas avoir d'informations sur des questions très spécifiques
        """)
    
    # Pied de page
    st.markdown("---")
    st.markdown(
        '<div style="text-align: center; color: #666; font-size: 0.9rem;">'
        'Projet académique - IA Générative & RAG<br>'
        'Chatbot spécialisé sur les sites archéologiques de Tunisie'
        '</div>',
        unsafe_allow_html=True
    )

if __name__ == "__main__":
    main()