from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List
import warnings
warnings.filterwarnings('ignore')

class EmbeddingGenerator:
    def __init__(self, model_name='all-MiniLM-L6-v2'):
        """Initialise le modèle d'embedding"""
        print(f"🔄 Chargement du modèle {model_name}...")
        self.model = SentenceTransformer(model_name)
        print("✅ Modèle chargé avec succès")
    
    def generate_embeddings(self, texts: List[str]) -> np.ndarray:
        """Génère les embeddings pour une liste de textes"""
        print(f"🔤 Génération des embeddings pour {len(texts)} textes...")
        
        embeddings = self.model.encode(
            texts,
            convert_to_tensor=False,
            show_progress_bar=True,
            normalize_embeddings=True
        )
        
        print(f"✅ Embeddings générés: shape {embeddings.shape}")
        return embeddings
    
    def test_model(self):
        """Teste le modèle avec un exemple simple"""
        test_texts = ["Carthage est un site archéologique", "Dougga est une ville romaine"]
        embeddings = self.generate_embeddings(test_texts)
        
        # Calculer la similarité
        similarity = np.dot(embeddings[0], embeddings[1])
        print(f"📊 Similarité entre les textes: {similarity:.4f}")
        
        return embeddings

if __name__ == "__main__":
    # Test du modèle
    embedder = EmbeddingGenerator()
    embedder.test_model()