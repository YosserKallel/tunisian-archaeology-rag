# add_missing_data.py
import json
import os

# Données MANQUELLES sur El Jem
missing_data = [
    {
        "id": "eljem_amphitheatre_real",
        "title": "Amphithéâtre d'El Jem - UNESCO",
        "content": "L'amphithéâtre d'El Jem, construit vers 238 ap. J.-C. sous l'empereur Gordien III, est le plus grand amphithéâtre romain d'Afrique après le Colisée de Rome. Dimensions: 148 mètres (grand axe), 124 mètres (petit axe), 36 mètres de hauteur. Capacité: 35 000 spectateurs. Époque: Romaine (IIIe siècle). Fonction: Spectacles de gladiateurs, chasses aux fauves (venationes), exécutions publiques. Classé au patrimoine mondial de l'UNESCO en 1979.",
        "metadata": {
            "site_archaeologique": "El Jem",
            "periode": "Romain",
            "source": "UNESCO",
            "langue": "fr",
            "fiabilite": 0.95
        }
    }
]

# Sauvegarder
os.makedirs("data/missing_sites", exist_ok=True)
for i, doc in enumerate(missing_data):
    with open(f"data/missing_sites/eljem_{i}.json", 'w', encoding='utf-8') as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)
print("✅ Données manquantes ajoutées pour El Jem")