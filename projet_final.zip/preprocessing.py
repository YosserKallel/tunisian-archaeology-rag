import json
import re
from pathlib import Path
from typing import List, Dict
import hashlib
import os

class DocumentProcessor:
    def __init__(self):
        pass
    
    def load_documents(self, folder_path: str) -> List[Dict]:
        """Charge tous les documents JSON d'un dossier"""
        documents = []
        path = Path(folder_path)
        
        for json_file in path.glob("*.json"):
            with open(json_file, 'r', encoding='utf-8') as f:
                document = json.load(f)
                documents.append(document)
        
        print(f"📂 {len(documents)} documents chargés depuis {folder_path}")
        return documents
    
    def clean_text(self, text: str) -> str:
        """Nettoie le texte"""
        # Supprimer les références [1], [2], etc.
        text = re.sub(r'\[\d+\]', '', text)
        
        # Supprimer les URLs
        text = re.sub(r'http\S+|www\S+', '', text)
        
        # Normaliser les espaces
        text = re.sub(r'\s+', ' ', text)
        
        # Supprimer les caractères spéciaux non désirés
        text = re.sub(r'[^\w\s.,;:!?()«»-]', '', text)
        
        return text.strip()
    
    def fix_metadata(self, metadata_dict):
        """Convertit les listes en strings pour ChromaDB"""
        fixed = {}
        for key, value in metadata_dict.items():
            if value is None:
                fixed[key] = ""  # Remplace None par string vide
            elif isinstance(value, list):
                fixed[key] = ', '.join(str(v) for v in value)
            else:
                fixed[key] = value
        return fixed
    
    def create_chunks(self, documents: List[Dict], chunk_size: int = 300, overlap: int = 50) -> List[Dict]:
        """Découpe les documents en chunks avec chevauchement"""
        all_chunks = []
        
        for doc in documents:
            # Nettoyer le texte
            clean_content = self.clean_text(doc['content'])
            
            # Découper en phrases
            sentences = re.split(r'(?<=[.!?])\s+', clean_content)
            
            # Créer des chunks avec chevauchement
            for i in range(0, len(sentences), chunk_size - overlap):
                chunk_sentences = sentences[i:i + chunk_size]
                if not chunk_sentences:
                    continue
                    
                chunk_text = ' '.join(chunk_sentences)
                
                # Créer un ID unique
                chunk_id = hashlib.md5(f"{doc['id']}_{i}".encode()).hexdigest()[:8]
                
                chunk_data = {
                    'id': f"{doc['id']}_chunk_{chunk_id}",
                    'text': chunk_text,
                    'metadata': self.fix_metadata({
                        **doc['metadata'],
                        'chunk_index': i,
                        'parent_doc_id': doc['id'],
                        'parent_title': doc['title'],
                        'text_length': len(chunk_text),
                        'num_sentences': len(chunk_sentences)
                    })
                }
                all_chunks.append(chunk_data)
        
        print(f"✂️  {len(all_chunks)} chunks créés à partir de {len(documents)} documents")
        return all_chunks
    
    def save_chunks(self, chunks: List[Dict], output_file: str):
        """Sauvegarde les chunks dans un fichier JSON"""
        # Créer le dossier s'il n'existe pas
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(chunks, f, ensure_ascii=False, indent=2)
        
        print(f"💾 Chunks sauvegardés dans {output_file}")

def process_documents():
    processor = DocumentProcessor()
    
    # 1. Charger les 50 documents
    print("📚 Chargement des 50 documents...")
    documents = processor.load_documents("data/raw_50")
    
    if len(documents) < 50:
        print(f"⚠️  ATTENTION: Seulement {len(documents)} documents trouvés.")
        print("   Exécutez d'abord: python create_50_docs.py")
        return []
    
    # 2. Créer les chunks (400 mots avec chevauchement de 80)
    print("✂️  Découpage en chunks sémantiques...")
    chunks = processor.create_chunks(documents, chunk_size=400, overlap=80)
    
    # 3. Sauvegarder
    processor.save_chunks(chunks, "data/processed/chunks.json")
    
    # 4. Statistiques pour le rapport
    print("\n" + "="*60)
    print("📊 STATISTIQUES (pour le rapport du professeur)")
    print("="*60)
    
    # Par site
    sites = {}
    sources = {}
    for chunk in chunks:
        site = chunk['metadata']['site_archaeologique']
        source = chunk['metadata']['source']
        sites[site] = sites.get(site, 0) + 1
        sources[source] = sources.get(source, 0) + 1
    
    print(f"• Documents originaux: {len(documents)}")
    print(f"• Chunks créés: {len(chunks)}")
    print(f"• Taille moyenne chunk: {sum(len(c['text']) for c in chunks)//len(chunks)} caractères")
    print(f"• Sites couverts: {len(sites)}")
    
    print("\n• Répartition par site (top 5):")
    for site, count in sorted(sites.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {site}: {count} chunks")
    
    print("\n• Sources principales:")
    for source, count in sorted(sources.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {source}: {count} chunks")
    
    return chunks

if __name__ == "__main__":
    process_documents()